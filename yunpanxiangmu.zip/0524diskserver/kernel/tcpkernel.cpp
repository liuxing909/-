﻿#include "tcpkernel.h"

TCPKernel *TCPKernel::m_pKernel = new TCPKernel;

TCPKernel::TCPKernel() {
    m_pTCPNet = new TCPNet;
    m_pSQL = new CMySql;
    strcpy(m_szSystemPath,"D:/qtfuxi/disk/");
}

TCPKernel::~TCPKernel()
{
    delete m_pTCPNet;
    delete m_pSQL;
}

bool TCPKernel::open()
{
    if(!m_pTCPNet->initNetWork()) {
        printf("init network err\n");
        return false;
    }
    if(!m_pSQL->ConnectMySql("localhost","root","123456","0804test")) {
        printf("connect mysql err\n");
        return false;
    }
    return true;
}

void TCPKernel::close()
{
    m_pTCPNet->unInitNetWork("over");
}

void TCPKernel::dealData(SOCKET sock, char *szbuf)
{
    switch(*szbuf) {
    case _default_protocol_register_rq:
        {
        registerrq(sock,szbuf);
        }
        break;
    case _default_protocol_login_rq:
        {
            loginrq(sock,szbuf);
        }
        break;
    case _default_protocol_getfilelist_rq:
            getfilelist(sock,szbuf);
        break;
    case _default_protocol_uploadfileinfo_rq:
        uploadfileinforq(sock,szbuf);
        break;
    case _default_protocol_uploadfileblock_rq:
        uploadfileblockrq(sock,szbuf);
        break;
    case _default_protocol_sharelink_rq:
        sharelinkrq(sock,szbuf);
        break;
    case _default_protocol_getlink_rq:
        getlinkrq(sock,szbuf);
        break;


    }
}


void TCPKernel::registerrq(SOCKET sock, char *szbuf)
{
    STRU_REGISER_RQ *psrr = (STRU_REGISER_RQ*) szbuf;
    char szsql[SQLLEN] = {0};
    char szPath[MAX_PATH] = {0};
    STRU_REGISER_RS srr;
    list<string> lststr;
    srr.m_szResult = _register_err;
    //将数据插入到数据库中
    sprintf(szsql,"insert into user(u_name,u_password,u_tel) values('%s','%s',%lld)",
            psrr->m_szName,psrr->m_szPassword,psrr->m_tel);
    if(m_pSQL->UpdateMySql(szsql)) {
        //更新成功
        srr.m_szResult = _register_success;
        //获取当前用户目录
        sprintf(szsql,"select u_id from user where u_tel = %lld",psrr->m_tel);
        m_pSQL->SelectMySql(szsql,1,lststr);
        if(lststr.size() >0) {
            string strUserId = lststr.front();
            lststr.pop_front();
            //为当前用户创建目录  D:/zijixue/disk/ + userId
            sprintf(szPath,"%s%s",m_szSystemPath,strUserId.c_str());
            CreateDirectoryA(szPath,0);;
        }

    }
    //发送回复--序列化--反序列化
    m_pTCPNet->sendDate(sock,(char*)&srr,sizeof(srr));

}



void TCPKernel::loginrq(SOCKET sock, char *szbuf)
{
    STRU_LOGIN_RQ *pslr = (STRU_LOGIN_RQ*) szbuf;
    char szsql[SQLLEN] = {0};
    list<string> lststr;
    STRU_LOGIN_RS slr;
    slr.m_szResult=_login_usernoexists;
    sprintf(szsql,"select u_id,u_password from user where u_name = '%s';",pslr->m_szName);
    m_pSQL->SelectMySql(szsql,2,lststr);
    //检验用户名 --是否存在
    if(lststr.size()>0) {
        slr.m_szResult=_login_passworderr;
        //校验密码是否正确
        string strUserId = lststr.front();
        lststr.pop_front();
        string strPassword = lststr.front();
        lststr.pop_front();
        if(0 == strcmp(pslr->m_szPassword,strPassword.c_str())) {
            //密码正确
            slr.m_szResult = _login_success;
            slr.m_userId = atoll(strUserId.c_str());
        }
    }
    //发送回复
    m_pTCPNet->sendDate(sock,(char*)&slr,sizeof(slr));
}



void TCPKernel::getfilelist(SOCKET sock, char *szbuf)
{
    STRU_GETFILELIST_RQ *psgr = (STRU_GETFILELIST_RQ*)szbuf;
    char szsql[SQLLEN] = {0};
    list<string> lststr;
    STRU_GETFRIENDLIST_RS sgr;
    sprintf(szsql,"select f_name,f_size,f_uploadtime from myview where u_id = '%lld';",psgr->m_userId);
    //获取文件列表
    m_pSQL->SelectMySql(szsql,3,lststr);
    int i=0;
    while(lststr.size()>0) {
        string strFileName = lststr.front();
        lststr.pop_front();
        string strFileSize = lststr.front();
        lststr.pop_front();
        string strFileUpLoadtime = lststr.front();
        lststr.pop_front();
        strcpy(sgr.m_aryInfo[i].m_szFileName,strFileName.c_str());
        strcpy(sgr.m_aryInfo[i].m_szFileDateTime,strFileUpLoadtime.c_str());
        sgr.m_aryInfo[i].m_fileSize = atoll(strFileSize.c_str());
        i++;
        if(i == FILENUM || lststr.size() == 0) {
            sgr.m_fileNum = i;
            m_pTCPNet->sendDate(sock,(const char*)&sgr,sizeof(sgr));
            ZeroMemory(sgr.m_aryInfo,sizeof(sgr.m_aryInfo));
            i=0;
        }
    }
}

void TCPKernel::uploadfileinforq(SOCKET sock, char *szbuf)
{
    STRU_UPLOADFILEINFO_RQ *psur = (STRU_UPLOADFILEINFO_RQ*)szbuf;
    char szsql[SQLLEN] = {0};
    list<string> lststr;
    STRU_UPLOADFILEINFO_RS sur;
    strcpy(sur.m_sizFileName,psur->m_sizFileName);
    sur.m_pos = 0;
    sprintf(szsql,"select u_id,f_id,f_count from myview where f_md5 = '%s'",psur->m_szFileMD5);
    m_pSQL->SelectMySql(szsql,3,lststr);
    //1.判断数据库中是否存在热门文件
    if(lststr.size() >0) {
        string strUserId = lststr.front();
        lststr.pop_front();
        string strFileId = lststr.front();
        lststr.pop_front();
        string strFilecount = lststr.front();
        lststr.pop_front();
        long long userId = atoll(strUserId.c_str());
        long long FileId = atoll(strFileId.c_str());
        sur.m_fileId = FileId;
        if(psur->m_userId == userId) {
            //1.1判断这个文件是不是自己传过的，但是1.没有传完--断点续传 2.传完了--重复上传
            sur.m_szResult = _fileinfo_isuploaded;
            UploadFileInfo *pinfo = m_mapFileIdToFileInfo[FileId];
            if(pinfo) {
                sur.m_szResult = _fileinfo_continue;
                sur.m_pos = pinfo->m_pos;
            }

        }else {
            sur.m_szResult = _fileinfo_speedtransfer;
            //1.2如果这个文件是别人穿过的，存在则秒传成功--文件引用计数+1
            sprintf(szsql,"update file set f_count =  f_count+1 where f_id = %lld;",FileId);
            m_pSQL->UpdateMySql(szsql);
            //1.3将文件与用户信息 映射到user_file
            sprintf(szsql,"insert into user_file(u_id,f_id) values(%lld,%lld);",psur->m_userId,FileId);
            m_pSQL->UpdateMySql(szsql);
        }

    }else {
        sur.m_szResult = _fileinfo_normal;
        //2.数据库中不存在--正常传
        char szFilePath[MAX_PATH] = {0};
        //D:/zijixue/disk/ + userid / + filename
        //D:/zijixue/disk/1/test.txt
        sprintf(szFilePath,"%s%lld/%s",m_szSystemPath,psur->m_userId,psur->m_sizFileName);
        sprintf(szsql,"insert into file(f_name,f_size,f_path,f_md5) values('%s',%lld,'%s','%s')",
                psur->m_sizFileName,psur->m_sizFilesize,szFilePath,psur->m_szFileMD5);

        //2.1将文件信息加入到数据库中
        m_pSQL->UpdateMySql(szsql);
        //2.2将文件与用户信息 映射到user_file
        //获取文件ID
        sprintf(szsql,"select f_id from file where f_md5 = '%s'",psur->m_szFileMD5);
        m_pSQL->SelectMySql(szsql,1,lststr);
        if(lststr.size() >0) {
            string strFileId = lststr.front();
            lststr.pop_front();
            sur.m_fileId = atoll(strFileId.c_str());
            sprintf(szsql,"insert into user_file(u_id,f_id) values(%lld,%lld);",
                    psur->m_userId,atoll(strFileId.c_str()));
            m_pSQL->UpdateMySql(szsql);
        }

        //2.3 创建新文件
       FILE *pfile = fopen(szFilePath,"wb");
        //记录文件信息 filed，--（文件指针 文件大小 文件位置 userid）
       UploadFileInfo *p = new UploadFileInfo;
       p->m_pFile = pfile;
       p->m_fileSize = psur->m_sizFilesize;
       p->m_pos = 0;
       p->m_userId = psur->m_userId;
       m_mapFileIdToFileInfo[sur.m_fileId] = p;
    }
    m_pTCPNet->sendDate(sock,(char*)&sur,sizeof(sur));
}

void TCPKernel::uploadfileblockrq(SOCKET sock, char *szbuf)
{
    STRU_UPLOADFILEBLOCK_RQ *psur = (STRU_UPLOADFILEBLOCK_RQ* )szbuf;
    UploadFileInfo *p = m_mapFileIdToFileInfo[psur->m_fileId];
    if(!p) return;
    //将文件内容 写入到对应的文件中
    size_t nWriteNum = fwrite(psur->m_sizFileCotent,sizeof(char),psur->m_fileNum,p->m_pFile);
    if(nWriteNum >0) {
        p->m_pos+=nWriteNum;
        if(p->m_pos == p->m_fileSize) {
            fclose(p->m_pFile);

            auto ite = m_mapFileIdToFileInfo.begin();
            while(ite!=m_mapFileIdToFileInfo.end()) {
                if(ite->first == psur->m_fileId) {
                    m_mapFileIdToFileInfo.erase(ite);
                    break;
                }
                ite++;
            }
        }
    }
}

void TCPKernel::sharelinkrq(SOCKET sock, char *szbuf)
{
    STRU_SHARELINK_RQ *pssr = (STRU_SHARELINK_RQ*) szbuf;
    STRU_SHARELINK_RS ssr;
    strcpy(ssr.m_szFileName,pssr->m_szFileName);
    //生成码4位数字
    srand((unsigned int)time(0));
    char c;
    char szCode[MAXSIZE] = {0};
    for(int i=0;i<4;i++) {
        int randNum = rand() % 36;
        if(randNum < 10) {
            c = randNum + '0';//生成0-9对应的ASCII字符
        } else {
            c = randNum-10 + 'A'; //生成字母A-Z对应的ASCII字符
        }
        szCode[i] = c;
    }
    char szsql[SQLLEN] = {0};
    list<string> lststr;
    sprintf(szsql,"select f_id from myview where u_id = %lld and f_name = '%s'",pssr->m_userId,pssr->m_szFileName);
    m_pSQL->SelectMySql(szsql,1,lststr);
    if(lststr.size() >0) {
        string strFiled = lststr.front();
        lststr.pop_front();
        long long FileId = atoll(strFiled.c_str());
        //将分享的文件信息存储在数据库中
        sprintf(szsql,"insert into user_share(u_id,f_id,code) values(%lld,%lld,'%s')",
               pssr->m_userId,FileId,szCode);
        m_pSQL->UpdateMySql(szsql);


    }
    //发送回复
    strcpy(ssr.m_szCode,szCode);
    strcpy(ssr.m_szlink,"D:/Code/test.html");
    m_pTCPNet->sendDate(sock,(char*)&ssr,sizeof(ssr));
}

void TCPKernel::getlinkrq(SOCKET sock, char *szbuf)
{
    STRU_GETLINK_RQ *psgr = (STRU_GETLINK_RQ*) szbuf;
    list<string> lststr;
    STRU_GETLINK_RS sgr;
    char szsql[SQLLEN] = {0};
    //1.通过提取码 找到映射到userid 以及 fileid;
    sprintf(szsql,"select u_id,f_id from user_share where code ='%s';",psgr->m_szCode);
    m_pSQL->SelectMySql(szsql,2,lststr);
    if(lststr.size() > 0) {
        string strUserId = lststr.front();
        lststr.pop_front();
        string strFileId = lststr.front();
        lststr.pop_front();
        long long userId = atoll(strUserId.c_str());
        long long FileId = atoll(strFileId.c_str());
        //2.通过FILEID --filename,filesize,fileuploadtime
        sprintf(szsql,"select f_name,f_size,f_uploadtime from file where f_id = %lld;",FileId);
        m_pSQL->SelectMySql(szsql,3,lststr);
        if(lststr.size() > 0) {
            string strFileName = lststr.front();
            lststr.pop_front();
            string strFileSize = lststr.front();
            lststr.pop_front();
            string strFileUploadTime = lststr.front();
            lststr.pop_front();
            strcpy(sgr.m_szFileUploadTime,strFileUploadTime.c_str());
            strcpy(sgr.m_szFileName,strFileName.c_str());
            sgr.m_FileSize = atoll(strFileSize.c_str());
            sgr.m_userId = userId;
        }
        //3.文件引用计数+1
        sprintf(szsql,"update file set f_count = f_count + 1 where f_id = %lld;",FileId);
        m_pSQL->UpdateMySql(szsql);
    }

    //4.发送回复
    m_pTCPNet->sendDate(sock,(char*)&sgr,sizeof(sgr));
}





