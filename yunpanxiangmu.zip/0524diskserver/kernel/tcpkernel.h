﻿#ifndef TCPKERNEL_H
#define TCPKERNEL_H

#include "IKernel.h"
#include "../server/tcpnet.h"
#include"../mysql/CMySql.h"
#include "packdef.h"
#include <map>
#include<time.h>
//记录文件信息 filed，--（文件指针 文件大小 文件位置 userid）

struct UploadFileInfo{
    FILE *m_pFile;
    long long m_fileSize;
    long long m_pos;
    long long m_userId;
};

class TCPKernel : public IKernel
{
public:
    TCPKernel();
    ~TCPKernel();
public:
    virtual bool open();
    virtual void close();
    virtual void dealData(SOCKET sock,char *szbuf);
public:
    //单例模式 -- 懒汉模式 ,不支持线程安全
    //单例模式 -- 饿汉模式，支持线程安全 高效
    static IKernel* getKernel() {
        return m_pKernel;
    }
public:
    void registerrq(SOCKET sock,char *szbuf);
    void loginrq(SOCKET sock,char *szbuf);
    void getfilelist(SOCKET sock,char *szbuf);
    void uploadfileinforq(SOCKET sock,char *szbuf);
    void uploadfileblockrq(SOCKET sock,char *szbuf);
    void sharelinkrq(SOCKET sock,char *szbuf);
    void getlinkrq(SOCKET sock,char *szbuf);
private:
    INet *m_pTCPNet;
    CMySql *m_pSQL;
    static TCPKernel *m_pKernel;//静态类成员
    char m_szSystemPath[MAX_PATH];
    std::map<long long ,UploadFileInfo*> m_mapFileIdToFileInfo;
};

#endif // TCPKERNEL_H
