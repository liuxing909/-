#include "login.h"
#include "ui_login.h"


login::login(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::login)
{
    ui->setupUi(this);
    setWindowTitle("云盘");
    setWindowIcon(QIcon("./disk.png"));


}

login::~login()
{
    delete ui;
}

void login::slots_sregister(STRU_REGISER_RS *psrr)
{
   const char*pszReasult = "register_err";
    if( psrr->m_szResult == _register_success)
        pszReasult = "register_success";
    QMessageBox::information(this,"sregister",pszReasult);
}

//注册
void login::on_pushButton_clicked()
{
    QString strTel = ui->lineEdit_rtel->text();
    QString strUser = ui->lineEdit_ruser->text();
    QString strPassword = ui->lineEdit_rpassword->text();

    STRU_REGISER_RQ sgr;
    strcpy(sgr.m_szName,strUser.toStdString().c_str());
    strcpy(sgr.m_szPassword,strPassword.toStdString().c_str());
    sgr.m_tel = strTel.toLongLong();

    m_PKernel->sendDate((char*) &sgr,sizeof(sgr));

    }

 //登录
void login::on_pushButton_2_clicked()
{
    QString strUser = ui->lineEdit_luser->text();
    QString strPassword = ui->lineEdit_lpassword->text();
    STRU_LOGIN_RQ slr;
    strcpy(slr.m_szName,strUser.toStdString().c_str());
    strcpy(slr.m_szPassword,strPassword.toStdString().c_str());


    m_PKernel->sendDate((char*) &slr,sizeof(slr));



}

