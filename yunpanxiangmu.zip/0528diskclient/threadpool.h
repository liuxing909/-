#ifndef THREADPOOL_H
#define THREADPOOL_H
#include<windows.h>
#include<queue>
#include<list>
#include<stdio.h>
#include<stdlib.h>
#define MAXLEN 10000
class itask{
public:
    itask() {

    }
    virtual ~itask() {

    }
public:
    virtual void run() = 0;
};

class threadpool
{
public:
    threadpool();
    ~threadpool();
public:
    //1.创建线程池
    bool createThreadpool(long lminThreadnum,long lmaxThreadnum);
    //2.销毁线程池
    void destoryThreadpool();
    //3.线程函数
    static DWORD WINAPI threadproc(LPVOID lpvoid);
    //4.投递任务
    bool push(itask*);
private:
    std::queue<itask*> m_qitask;
    std::list<HANDLE> m_lstThread;
    HANDLE m_hSemaphore;
    bool m_bFlagQuit;
    long m_lCreateThreadNum;
    long m_lRunThreadNum;
    long m_lMaxThreadNum;
    HANDLE m_hMutex;
};

#endif // THREADPOOL_H
