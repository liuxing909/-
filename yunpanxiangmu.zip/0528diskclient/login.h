#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include <QDebug>
#include"Packdef.h"
#include "kernel/IKernel.h"
#include<QMessageBox>

namespace Ui {
class login;
}

class login : public QWidget
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();

public slots:
    void slots_sregister(STRU_REGISER_RS* psrr);

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

public:
    void setKernel(IKernel *pKernel) {
        m_PKernel = pKernel;
    }

private:
    Ui::login *ui;
    IKernel *m_PKernel;
};

#endif // LOGIN_H
