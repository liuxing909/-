#ifndef PACKDEF_H
#define PACKDEF_H

#define _default_protocol_base   10

//注册
#define _default_protocol_register_rq   _default_protocol_base +1
#define _default_protocol_register_rs   _default_protocol_base +2
//登录
#define _default_protocol_login_rq   _default_protocol_base +3
#define _default_protocol_login_rs   _default_protocol_base +4
//获取文件列表
#define _default_protocol_getfilelist_rq   _default_protocol_base +5
#define _default_protocol_getfilelist_rs   _default_protocol_base +6
//上传文件--正常传，断点续传，妙传
#define _default_protocol_uploadfileinfo_rq   _default_protocol_base +7
#define _default_protocol_uploadfileinfo_rs   _default_protocol_base +8
#define _default_protocol_uploadfileblock_rq   _default_protocol_base +9
#define _default_protocol_uploadfileblock_rs  _default_protocol_base +10
//搜索文件
//与好友聊天
#define _default_protocol_selectfriendchat_rq   _default_protocol_base +7
//发送文件
#define _default_protocol_sendfileinfo_rq   _default_protocol_base +8
#define _default_protocol_sendfileinfo_rs   _default_protocol_base +9

#define _default_protocol_sendfileblock_rq   _default_protocol_base +10


//分享
#define _default_protocol_sharelink_rq  _default_protocol_base +11
#define _default_protocol_sharelink_rs _default_protocol_base +12
//提取
#define _default_protocol_getlink_rq  _default_protocol_base +13
#define _default_protocol_getlink_rs  _default_protocol_base +14


#define MAXSIZE  45
#define FILENUM   15
#define SQLLEN     300
#define CONTENTSIZE 1024
#define MAX_PATH    260
#define ONE_PAGE    4096

#define _register_err  0
#define _register_success  1

#define _login_usernoexists    0
#define _login_passworderr     1
#define _login_success         2

#define _fileinfo_isuploaded 0  //文件已经上传过 重复上传
#define _fileinfo_continue   1 //断点续传
#define _fileinfo_speedtransfer 2 //秒传
#define _fileinfo_normal        3 //正常传


//协议包
struct STRU_BASE
{
    char  m_nType;
};

//申请账号
struct STRU_REGISER_RQ: public STRU_BASE
{
    STRU_REGISER_RQ()
    {
        m_nType = _default_protocol_register_rq;
    }
    char m_szName[MAXSIZE];
    char m_szPassword[MAXSIZE];
    long long m_tel;

};
struct STRU_REGISER_RS: public STRU_BASE
{
    STRU_REGISER_RS()
    {
        m_nType = _default_protocol_register_rs;
    }
    char m_szResult;
};

//登录
struct STRU_LOGIN_RQ: public STRU_BASE
{
    STRU_LOGIN_RQ()
    {
        m_nType = _default_protocol_login_rq;
    }
    char m_szName[MAXSIZE];
    char m_szPassword[MAXSIZE];
};
struct STRU_LOGIN_RS: public STRU_BASE
{
    STRU_LOGIN_RS()
    {
        m_nType = _default_protocol_login_rs;
    }
    long long m_userId;
    char m_szResult;
};

//获取文件列表

struct STRU_GETFILELIST_RQ: public STRU_BASE
{
    STRU_GETFILELIST_RQ()
    {
        m_nType = _default_protocol_getfilelist_rq;
    }
    long long m_userId;
};

struct FileInfo
{
    char m_szFileName[MAXSIZE];
    char m_szFileDateTime[MAXSIZE];
    long long m_fileSize;
};

struct STRU_GETFRIENDLIST_RS: public STRU_BASE
{
    STRU_GETFRIENDLIST_RS()
    {
        m_nType = _default_protocol_getfilelist_rs;
    }
    FileInfo m_aryInfo[FILENUM];
    long m_fileNum;
};

struct STRU_UPLOADFILEINFO_RQ: public STRU_BASE{
    STRU_UPLOADFILEINFO_RQ() {
        m_nType = _default_protocol_uploadfileinfo_rq;
    }
    long long m_userId;
    char m_sizFileName[MAXSIZE];
    long long m_sizFilesize;
    char m_szFileMD5[MAXSIZE];
};
struct STRU_UPLOADFILEINFO_RS: public STRU_BASE{
    STRU_UPLOADFILEINFO_RS() {
        m_nType = _default_protocol_uploadfileinfo_rs;
    }

    char m_sizFileName[MAXSIZE];
    long long m_fileId;
    long long m_pos;
    char m_szResult;
};

struct STRU_UPLOADFILEBLOCK_RQ: public STRU_BASE{
    STRU_UPLOADFILEBLOCK_RQ() {
        m_nType = _default_protocol_uploadfileblock_rq;
    }
    long long m_fileId;
    char m_sizFileCotent[ONE_PAGE];
    long m_fileNum;
};

//分享
struct STRU_SHARELINK_RQ: public STRU_BASE{
    STRU_SHARELINK_RQ() {
        m_nType = _default_protocol_sharelink_rq;
    }
    long long m_userId;
    char m_szFileName[MAXSIZE];
};

struct STRU_SHARELINK_RS: public STRU_BASE{
    STRU_SHARELINK_RS() {
        m_nType = _default_protocol_sharelink_rs;
    }
    char m_szFileName[MAXSIZE];
    char m_szlink[MAXSIZE];
    char m_szCode[MAXSIZE];
};


//提取
struct STRU_GETLINK_RQ: public STRU_BASE{
    STRU_GETLINK_RQ() {
        m_nType = _default_protocol_getlink_rq;
    }
    long long m_userId;
    char m_szCode[MAXSIZE];
};

struct STRU_GETLINK_RS: public STRU_BASE{
    STRU_GETLINK_RS() {
        m_nType = _default_protocol_getlink_rs;
    }
    long long m_userId;
    char m_szFileName[MAXSIZE];
    long long m_FileSize;
    char m_szFileUploadTime[MAXSIZE];
};


#endif // PACKDEF_H


// 用户表user(u_id,u_name,u_password,u_tel)
// 文件信息表 file(f_id,f_name,f_size,f_uploadtime,f_path,f_count,f_mds)
//user_file(num,u_id,f_id)


