#include "widget.h"
#include "ui_widget.h"
#include "ui_login.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowTitle("文件上传界面");
    setWindowIcon(QIcon("./wenjian.jpg"));
    m_pKernel = new TCPKernel;
    m_pLogin =  new login;
    m_pLogin->setKernel(m_pKernel);
    m_pLogin->show();
    if(m_pKernel->connect()) {
        qDebug()<<"connecy success";
    } else {
        QMessageBox::information(this,"err","connect err");
    }

    //创建线程池
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    m_tp.createThreadpool(1,si.dwNumberOfProcessors/1-0.8);

    connect((TCPKernel*)m_pKernel,&TCPKernel::signal_sregister,m_pLogin,&login::slots_sregister,Qt::BlockingQueuedConnection);
    connect((TCPKernel*)m_pKernel,&TCPKernel::signal_login,this,&Widget::slots_login,Qt::BlockingQueuedConnection);
    connect((TCPKernel*)m_pKernel,&TCPKernel::signal_getfilelist,this,&Widget::slots_getfilelist,Qt::BlockingQueuedConnection);
    connect((TCPKernel*)m_pKernel,&TCPKernel::signal_uploadfileinfo,this,&Widget::slots_uploadfileinfo,Qt::BlockingQueuedConnection);
    connect((TCPKernel*)m_pKernel,&TCPKernel::signal_sharelink,this,&Widget::slots_sharelink,Qt::BlockingQueuedConnection);
    connect((TCPKernel*)m_pKernel,&TCPKernel::signal_html,this,&Widget::slots_html,Qt::BlockingQueuedConnection);
    connect((TCPKernel*)m_pKernel,&TCPKernel::signal_getlink,this,&Widget::slots_getlink,Qt::BlockingQueuedConnection);

}

Widget::~Widget()
{
    delete ui;
    delete m_pKernel;
    delete m_pLogin;
    m_tp.destoryThreadpool();
}

void Widget::slots_login(STRU_LOGIN_RS *plrr)
{
    const char*pszReasult = "login_usernoexists";
    if( plrr->m_szResult == _login_passworderr){
        pszReasult = "password err";
    }else if(plrr->m_szResult == _login_success) {
        //关闭登录窗口
        m_pLogin->hide();
        //显示主窗口
        this->show();
        m_userId = plrr->m_userId;
        //登录成功
        //获取文件列表请求
        STRU_GETFILELIST_RQ sgr;
        sgr.m_userId = plrr->m_userId;
        m_pKernel->sendDate((char*)&sgr,sizeof(sgr));
        return;
    }

    QMessageBox::information(this,"login",pszReasult);
}

void Widget::slots_getfilelist(STRU_GETFRIENDLIST_RS *psgr)
{
    m_nFileNum = psgr->m_fileNum;
    QTableWidgetItem *pitem;
    for(int i=0;i<psgr->m_fileNum;i++) {
        //文件名
        pitem = new QTableWidgetItem(psgr->m_aryInfo[i].m_szFileName);
        ui->tableWidget->setItem(i,0,pitem);
        //文件大小
        QString strSize = QString::number(psgr->m_aryInfo[i].m_fileSize);
        pitem = new QTableWidgetItem(strSize);
        ui->tableWidget->setItem(i,1,pitem);
        //文件上传时间
        pitem = new QTableWidgetItem(psgr->m_aryInfo[i].m_szFileDateTime);
         ui->tableWidget->setItem(i,2,pitem);
    }
}

void SendFileItask::run(){
    FILE *pfile = fopen(m_pinfo->m_szFilePath,"rb");
    //如果是断点续传
    if(m_pos) {
        //将文件指针移动到指定位置
        fseek(pfile,m_pos,SEEK_SET);
    }
    //正常发送文件内容
    STRU_UPLOADFILEBLOCK_RQ sur;
    sur.m_fileId = m_FileId;
    while(1) {
        ssize_t nReanNum = fread(sur.m_sizFileCotent,sizeof(char),sizeof(sur.m_sizFileCotent),pfile);
        if(nReanNum >0) {
            sur.m_fileNum = nReanNum;
            m_pWidget->m_pKernel->sendDate((char*)&sur,sizeof(sur));

        } else {
            break;
        }
    }
    fclose(pfile);
    //将映射从map中移除
    QString strFilePath = m_pinfo->m_szFilePath;
    strFilePath = strFilePath.section('/',-1);
    auto ite =  m_pWidget->m_mapFileNameToFileInfo.begin();
    while(ite!= m_pWidget->m_mapFileNameToFileInfo.end()) {
        if(ite->first == strFilePath) {
             m_pWidget->m_mapFileNameToFileInfo.erase(ite);
            break;
        }
        ite++;
    }
}

void Widget::slots_uploadfileinfo(STRU_UPLOADFILEINFO_RS *psur)
{
    QString strFileName = psur->m_sizFileName;
    UploadFileInfo *pinfo = m_mapFileNameToFileInfo[strFileName];
    //处理文件相关内容
    if(psur->m_szResult == _fileinfo_isuploaded)
    {
        QMessageBox::information(this,"uploadfile","file is uploaded");
        return;
    } else if(psur->m_szResult == _fileinfo_speedtransfer) {
        //文件已经上传

    }else if(psur->m_szResult == _fileinfo_continue || psur->m_szResult == _fileinfo_normal) {
       //将任务投递到线程池
        itask *p = new SendFileItask(pinfo,psur->m_pos,psur->m_fileId,this);
        m_tp.push(p);
    }

    //1.将文件信息，显示到控件上
    QTableWidgetItem *p =new QTableWidgetItem(strFileName);
    ui->tableWidget->setItem(m_nFileNum,0,p);
    QString strFileSize = QString::number(pinfo->m_fileSize);
    p = new QTableWidgetItem(strFileSize);
    ui->tableWidget->setItem(m_nFileNum,1,p);
    QDateTime datetime = QDateTime::currentDateTime();
    QTime time = QTime::currentTime();
    QString strDate = datetime.toString("dd.MM.yyyy");
    QString strTime = time.toString("HH:mm:ss");
    p = new QTableWidgetItem(strDate+" "+strTime);
    ui->tableWidget->setItem(m_nFileNum,2,p);
    ++m_nFileNum;

    //2.提示文件上传成功
    QMessageBox::information(this,"uploadfile","file upload success");
}




void Widget::slots_sharelink(STRU_SHARELINK_RS *pssr)
{
    QString strLink = pssr->m_szlink;
    strLink = strLink +" "+ pssr->m_szCode;
    QMessageBox::information(this,"share link",strLink);
}

void Widget::slots_getlink(STRU_GETLINK_RS *psgr)
{
    if(psgr->m_userId == m_userId) {
        QMessageBox::information(this,"get link","file is yourself");
        return;
    } else {
        QTableWidgetItem *p =new QTableWidgetItem(psgr->m_szFileName);
        ui->tableWidget->setItem(m_nFileNum,0,p);
        QString strFileSize = QString::number(psgr->m_FileSize);
        p = new QTableWidgetItem(strFileSize);
        ui->tableWidget->setItem(m_nFileNum,1,p);

        p = new QTableWidgetItem(psgr->m_szFileUploadTime);
        ui->tableWidget->setItem(m_nFileNum,2,p);

        ++m_nFileNum;
        QMessageBox::information(this,"get link","success");

    }
}

void Widget::slots_html(QString strCode)
{
    //像服务器发送提取链接的请求
    STRU_GETLINK_RQ sgr;
    sgr.m_userId = m_userId;
    strcpy(sgr.m_szCode,strCode.toStdString().c_str());
    m_pKernel->sendDate((char*)&sgr,sizeof(sgr));

}



string FileDigest(QString filename) {
    QFile file(filename);

    file.open(QIODevice::ReadOnly);
    if(!file.isOpen())
        return "";
    MD5 md5;
    char buffer[1024];
    while(1)
    {
        qint64 length = file.read(buffer,1024);

        if(length > 0)
            md5.update(buffer,length);
        else
            break;
    }
    file.close();
    return md5.toString();
}


void Widget::on_pushButton_clicked()
{
    //获取要上传的文件信息（文件名，文件大小，文件MD5）
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open File"),
                                                    ".",
                                                   "ALL files(*.*);;Images (*.png *.xpm *.jpg);;Text files (*.txt);;XML files (*.xml)"
                                                    );

    QString fileName = filePath.section('/',-1);
    long long filesize;

    QFile file(filePath);
    if(file.open(QIODevice::ReadOnly)) {
        filesize = file.size();
        file.close();
    }

    string strMD5 = FileDigest(filePath);
    qDebug()<<strMD5.c_str();

    //上传文件信息
    STRU_UPLOADFILEINFO_RQ sur;
    sur.m_sizFilesize = filesize;
    sur.m_userId = m_userId;
    strcpy(sur.m_szFileMD5,strMD5.c_str());
    strcpy(sur.m_sizFileName,fileName.toStdString().c_str());

    m_pKernel->sendDate((char*)&sur,sizeof(sur));

    //记录当前文件信息，文件名---（文件路径，文件大小，文件ID，）
    UploadFileInfo *p = new UploadFileInfo;
    strcpy(p->m_szFilePath,filePath.toStdString().c_str());
    p->m_fileId = 0;
    p->m_fileSize = filesize;

    m_mapFileNameToFileInfo[fileName] = p;
}


void Widget::on_pushButton_5_clicked()
{
    //获取要分享的文件
    int nRow = ui->tableWidget->currentRow();
    if(nRow == -1) return;
    QTableWidgetItem *pItem = ui->tableWidget->item(nRow,0);

    //发送分享连接请求
    STRU_SHARELINK_RQ ssr;
    ssr.m_userId = m_userId;
    strcpy(ssr.m_szFileName,pItem->text().toStdString().c_str());

    m_pKernel->sendDate((char*)&ssr,sizeof(ssr));
}

